# CP Năng Lượng

Web cổ phiếu ngành Năng lượng Việt Nam.

- **Tên khi ghim màn hình chính:** CP Năng Lượng
- Mở site → Share / Thêm vào Màn hình chính (iOS) hoặc Cài đặt ứng dụng (Android)

## GitHub Pages
Bật Settings → Pages → Deploy from branch `main` / root.
